<?php
include('../config.php');

//buat array untuk menampung respon dari JSON
$respon = array();

// cek apakah nilai yang dikirimkan android sudah terisi
if (isset($_POST['idtransaksi']) && isset($_POST['jenistransaksi']) && isset($_POST['nominal'])) {
	
$idtransaksi  = $_POST['idtransaksi'];

$jenistransaksi    = $_POST['jenistransaksi'];

$qry_jenis  = mysql_query("SELECT * FROM stok_bahan WHERE nama_bahan ='$jenistransaksi'");
$data_jenis = mysql_fetch_array($qry_jenis);

$hpp   = $data_jenis['harga_per'];
$harga   = $data_jenis['hargaj'];

$nominal   = $_POST['nominal'];
//$total = $nominal*$harga;
//$bayar   = $_POST['bayar'];


//$kurang = $total-$bayar;
//$kembalian = $bayar-$total;

$tgl=date("Y-m-d");

      // query menambah data member
//if ($total > $bayar) {
	 //$insert=mysql_query("INSERT INTO tblpenjualan (kode_penjualan,pelanggan,total,bayar,kurang,tgl) VALUES ('$idtransaksi','Umum','$total','$bayar','$kurang','$tgl')");
	 //} else {
	 //$insert=mysql_query("INSERT INTO tblpenjualan (kode_penjualan,pelanggan,total,bayar,kembalian,tgl) VALUES ('$idtransaksi','Umum','$total','$bayar','$kembalian','$tgl')");
	 //}
     $result = mysql_query("INSERT INTO dtlpenjualan (kode_penjualan,nama_barang,jumlah,hpp,harga,tgl) VALUES ('$idtransaksi','$jenistransaksi','$nominal','$hpp','$harga','$tgl')");


    // cek apakah query berhasil menambah data
    if ($result) {
        // jika berhasil menambah data ke mysql
        $respon["sukses"] = 1;
        $respon["pesan"] = "Berhasil menambah data member.";

        // memprint/mencetak JSON respon
        echo json_encode($respon);
    } else {
        // gagal menambah data member
        $respon["sukses"] = 0;
        $respon["pesan"] = "Gagal menambah data.";
        
        // memprint/mencetak JSON respon
        echo json_encode($respon);
    }
} else {
    // jika data tidak terisi/tidak terset
    $respon["sukses"] = 0;
    $respon["pesan"] = "data belum terisi";

    //  memprint/mencetak JSON respon
    echo json_encode($respon);
 }
?>